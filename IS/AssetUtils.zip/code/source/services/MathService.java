package services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class MathService

{
	// ---( internal utility methods )---

	final static MathService _instance = new MathService();

	static MathService _newInstance() { return new MathService(); }

	static MathService _cast(Object o) { return (MathService)o; }

	// ---( server methods )---




	public static final void addFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addFloats)>> ---
		// @sigtype java 3.5
		// [i] recref:0:required a doc:docTypeRef_connector
		// [o] recref:0:required b doc:docTypeRef_memorypool
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// a
			IData	a = IDataUtil.getIData( pipelineCursor, "a" );
			if ( a != null)
			{
				IDataCursor aCursor = a.getCursor();
					String	__name = IDataUtil.getString( aCursor, "@name" );
		
					// i.threadInfo
					IData	threadInfo = IDataUtil.getIData( aCursor, "threadInfo" );
					if ( threadInfo != null)
					{
						IDataCursor threadInfoCursor = threadInfo.getCursor();
							String	__maxThreads = IDataUtil.getString( threadInfoCursor, "@maxThreads" );
							String	__currentThreadCount = IDataUtil.getString( threadInfoCursor, "@currentThreadCount" );
							String	__currentThreadsBusy = IDataUtil.getString( threadInfoCursor, "@currentThreadsBusy" );
						threadInfoCursor.destroy();
					}
		
					// i.requestInfo
					IData	requestInfo = IDataUtil.getIData( aCursor, "requestInfo" );
					if ( requestInfo != null)
					{
						IDataCursor requestInfoCursor = requestInfo.getCursor();
							String	__maxTime = IDataUtil.getString( requestInfoCursor, "@maxTime" );
							String	__processingTime = IDataUtil.getString( requestInfoCursor, "@processingTime" );
							String	__requestCount = IDataUtil.getString( requestInfoCursor, "@requestCount" );
							String	__errorCount = IDataUtil.getString( requestInfoCursor, "@errorCount" );
							String	__bytesReceived = IDataUtil.getString( requestInfoCursor, "@bytesReceived" );
							String	__bytesSent = IDataUtil.getString( requestInfoCursor, "@bytesSent" );
						requestInfoCursor.destroy();
					}
		
					// i.workers
					IData	workers = IDataUtil.getIData( aCursor, "workers" );
					if ( workers != null)
					{
						IDataCursor workersCursor = workers.getCursor();
		
							// i.worker
							IData[]	worker = IDataUtil.getIDataArray( workersCursor, "worker" );
							if ( worker != null)
							{
								for ( int i = 0; i < worker.length; i++ )
								{
									IDataCursor workerCursor = worker[i].getCursor();
										String	__stage = IDataUtil.getString( workerCursor, "@stage" );
										String	__requestProcessingTime = IDataUtil.getString( workerCursor, "@requestProcessingTime" );
										String	__requestBytesSent = IDataUtil.getString( workerCursor, "@requestBytesSent" );
										String	__requestBytesReceived = IDataUtil.getString( workerCursor, "@requestBytesReceived" );
										String	__remoteAddr = IDataUtil.getString( workerCursor, "@remoteAddr" );
										String	__virtualHost = IDataUtil.getString( workerCursor, "@virtualHost" );
										String	__method = IDataUtil.getString( workerCursor, "@method" );
										String	__currentUri = IDataUtil.getString( workerCursor, "@currentUri" );
										String	__currentQueryString = IDataUtil.getString( workerCursor, "@currentQueryString" );
										String	__protocol = IDataUtil.getString( workerCursor, "@protocol" );
									workerCursor.destroy();
								}
							}
						workersCursor.destroy();
					}
				aCursor.destroy();
			}
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		// b
		IData	b = IDataFactory.create();
		IDataCursor bCursor = b.getCursor();
		IDataUtil.put( bCursor, "@name", "@name" );
		IDataUtil.put( bCursor, "@type", "@type" );
		IDataUtil.put( bCursor, "@usageInit", "@usageInit" );
		IDataUtil.put( bCursor, "@usageCommitted", "@usageCommitted" );
		IDataUtil.put( bCursor, "@usageMax", "@usageMax" );
		IDataUtil.put( bCursor, "@usageUsed", "@usageUsed" );
		bCursor.destroy();
		IDataUtil.put( pipelineCursor_1, "b", b );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void divideFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(divideFloats)>> ---
		// @sigtype java 3.5
		// [i] recref:0:required a doc:docTypeRef_workers
		// [o] recref:0:required v doc:docTypeRef_worker
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// a
			IData	a = IDataUtil.getIData( pipelineCursor, "a" );
			if ( a != null)
			{
				IDataCursor aCursor = a.getCursor();
		
					// i.worker
					IData[]	worker = IDataUtil.getIDataArray( aCursor, "worker" );
					if ( worker != null)
					{
						for ( int i = 0; i < worker.length; i++ )
						{
							IDataCursor workerCursor = worker[i].getCursor();
								String	__stage = IDataUtil.getString( workerCursor, "@stage" );
								String	__requestProcessingTime = IDataUtil.getString( workerCursor, "@requestProcessingTime" );
								String	__requestBytesSent = IDataUtil.getString( workerCursor, "@requestBytesSent" );
								String	__requestBytesReceived = IDataUtil.getString( workerCursor, "@requestBytesReceived" );
								String	__remoteAddr = IDataUtil.getString( workerCursor, "@remoteAddr" );
								String	__virtualHost = IDataUtil.getString( workerCursor, "@virtualHost" );
								String	__method = IDataUtil.getString( workerCursor, "@method" );
								String	__currentUri = IDataUtil.getString( workerCursor, "@currentUri" );
								String	__currentQueryString = IDataUtil.getString( workerCursor, "@currentQueryString" );
								String	__protocol = IDataUtil.getString( workerCursor, "@protocol" );
							workerCursor.destroy();
						}
					}
				aCursor.destroy();
			}
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		// v
		IData	v = IDataFactory.create();
		IDataCursor vCursor = v.getCursor();
		IDataUtil.put( vCursor, "@stage", "@stage" );
		IDataUtil.put( vCursor, "@requestProcessingTime", "@requestProcessingTime" );
		IDataUtil.put( vCursor, "@requestBytesSent", "@requestBytesSent" );
		IDataUtil.put( vCursor, "@requestBytesReceived", "@requestBytesReceived" );
		IDataUtil.put( vCursor, "@remoteAddr", "@remoteAddr" );
		IDataUtil.put( vCursor, "@virtualHost", "@virtualHost" );
		IDataUtil.put( vCursor, "@method", "@method" );
		IDataUtil.put( vCursor, "@currentUri", "@currentUri" );
		IDataUtil.put( vCursor, "@currentQueryString", "@currentQueryString" );
		IDataUtil.put( vCursor, "@protocol", "@protocol" );
		vCursor.destroy();
		IDataUtil.put( pipelineCursor_1, "v", v );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void multiplyFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(multiplyFloats)>> ---
		// @sigtype java 3.5
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// a
			IData	a = IDataUtil.getIData( pipelineCursor, "a" );
			if ( a != null)
			{
				IDataCursor aCursor = a.getCursor();
		
					// i.worker
					IData[]	worker = IDataUtil.getIDataArray( aCursor, "worker" );
					if ( worker != null)
					{
						for ( int i = 0; i < worker.length; i++ )
						{
							IDataCursor workerCursor = worker[i].getCursor();
								String	__stage = IDataUtil.getString( workerCursor, "@stage" );
								String	__requestProcessingTime = IDataUtil.getString( workerCursor, "@requestProcessingTime" );
								String	__requestBytesSent = IDataUtil.getString( workerCursor, "@requestBytesSent" );
								String	__requestBytesReceived = IDataUtil.getString( workerCursor, "@requestBytesReceived" );
								String	__remoteAddr = IDataUtil.getString( workerCursor, "@remoteAddr" );
								String	__virtualHost = IDataUtil.getString( workerCursor, "@virtualHost" );
								String	__method = IDataUtil.getString( workerCursor, "@method" );
								String	__currentUri = IDataUtil.getString( workerCursor, "@currentUri" );
								String	__currentQueryString = IDataUtil.getString( workerCursor, "@currentQueryString" );
								String	__protocol = IDataUtil.getString( workerCursor, "@protocol" );
							workerCursor.destroy();
						}
					}
				aCursor.destroy();
			}
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		// v
		IData	v = IDataFactory.create();
		IDataCursor vCursor = v.getCursor();
		IDataUtil.put( vCursor, "@stage", "@stage" );
		IDataUtil.put( vCursor, "@requestProcessingTime", "@requestProcessingTime" );
		IDataUtil.put( vCursor, "@requestBytesSent", "@requestBytesSent" );
		IDataUtil.put( vCursor, "@requestBytesReceived", "@requestBytesReceived" );
		IDataUtil.put( vCursor, "@remoteAddr", "@remoteAddr" );
		IDataUtil.put( vCursor, "@virtualHost", "@virtualHost" );
		IDataUtil.put( vCursor, "@method", "@method" );
		IDataUtil.put( vCursor, "@currentUri", "@currentUri" );
		IDataUtil.put( vCursor, "@currentQueryString", "@currentQueryString" );
		IDataUtil.put( vCursor, "@protocol", "@protocol" );
		vCursor.destroy();
		IDataUtil.put( pipelineCursor_1, "v", v );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void subtractFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(subtractFloats)>> ---
		// @sigtype java 3.5
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// a
			IData	a = IDataUtil.getIData( pipelineCursor, "a" );
			if ( a != null)
			{
				IDataCursor aCursor = a.getCursor();
		
					// i.worker
					IData[]	worker = IDataUtil.getIDataArray( aCursor, "worker" );
					if ( worker != null)
					{
						for ( int i = 0; i < worker.length; i++ )
						{
							IDataCursor workerCursor = worker[i].getCursor();
								String	__stage = IDataUtil.getString( workerCursor, "@stage" );
								String	__requestProcessingTime = IDataUtil.getString( workerCursor, "@requestProcessingTime" );
								String	__requestBytesSent = IDataUtil.getString( workerCursor, "@requestBytesSent" );
								String	__requestBytesReceived = IDataUtil.getString( workerCursor, "@requestBytesReceived" );
								String	__remoteAddr = IDataUtil.getString( workerCursor, "@remoteAddr" );
								String	__virtualHost = IDataUtil.getString( workerCursor, "@virtualHost" );
								String	__method = IDataUtil.getString( workerCursor, "@method" );
								String	__currentUri = IDataUtil.getString( workerCursor, "@currentUri" );
								String	__currentQueryString = IDataUtil.getString( workerCursor, "@currentQueryString" );
								String	__protocol = IDataUtil.getString( workerCursor, "@protocol" );
							workerCursor.destroy();
						}
					}
				aCursor.destroy();
			}
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		// v
		IData	v = IDataFactory.create();
		IDataCursor vCursor = v.getCursor();
		IDataUtil.put( vCursor, "@stage", "@stage" );
		IDataUtil.put( vCursor, "@requestProcessingTime", "@requestProcessingTime" );
		IDataUtil.put( vCursor, "@requestBytesSent", "@requestBytesSent" );
		IDataUtil.put( vCursor, "@requestBytesReceived", "@requestBytesReceived" );
		IDataUtil.put( vCursor, "@remoteAddr", "@remoteAddr" );
		IDataUtil.put( vCursor, "@virtualHost", "@virtualHost" );
		IDataUtil.put( vCursor, "@method", "@method" );
		IDataUtil.put( vCursor, "@currentUri", "@currentUri" );
		IDataUtil.put( vCursor, "@currentQueryString", "@currentQueryString" );
		IDataUtil.put( vCursor, "@protocol", "@protocol" );
		vCursor.destroy();
		IDataUtil.put( pipelineCursor_1, "v", v );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

