package service;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class MathService

{
	// ---( internal utility methods )---

	final static MathService _instance = new MathService();

	static MathService _newInstance() { return new MathService(); }

	static MathService _cast(Object o) { return (MathService)o; }

	// ---( server methods )---




	public static final void addFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addFloats)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}



	public static final void divideFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(divideFloats)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}



	public static final void multiplyFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(multiplyFloats)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}



	public static final void subtractFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(subtractFloats)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

