

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import static java.lang.System.*;
// --- <<IS-END-IMPORTS>> ---

public final class AutomationFolder

{
	// ---( internal utility methods )---

	final static AutomationFolder _instance = new AutomationFolder();

	static AutomationFolder _newInstance() { return new AutomationFolder(); }

	static AutomationFolder _cast(Object o) { return (AutomationFolder)o; }

	// ---( server methods )---




	public static final void js (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(js)>> ---
		// @sigtype java 3.5
			
		out.println();		
		// --- <<IS-END>> ---

                
	}
}

