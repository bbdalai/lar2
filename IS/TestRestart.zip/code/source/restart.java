

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class restart

{
	// ---( internal utility methods )---

	final static restart _instance = new restart();

	static restart _newInstance() { return new restart(); }

	static restart _cast(Object o) { return (restart)o; }

	// ---( server methods )---




	public static final void myjs1 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(myjs1)>> ---
		// @sigtype java 3.5
		IDataUtil.put(pipeline.getCursor(), "message", "Hello, World!!!");
		// --- <<IS-END>> ---

                
	}
}

