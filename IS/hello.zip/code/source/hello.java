

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.FlowExceptionHandlerImpl;
import com.wm.app.b2b.server.FlowSvcImpl;
import com.wm.app.b2b.server.InvokeState;
import com.wm.app.b2b.server.ns.Namespace;
import com.wm.app.b2b.util.ServerIf;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.flow.FlowService;
import com.wm.lang.flow.FlowState;
import com.wm.lang.ns.NSName;
import com.wm.lang.ns.NSNode;
// --- <<IS-END-IMPORTS>> ---

public final class hello

{
	// ---( internal utility methods )---

	final static hello _instance = new hello();

	static hello _newInstance() { return new hello(); }

	static hello _cast(Object o) { return (hello)o; }

	// ---( server methods )---




	public static final void javaservice1 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(javaservice1)>> ---
		// @sigtype java 3.5
		NSNode service = Namespace.current().getNode(NSName.create("a:fs1"));
		FlowSvcImpl flowService = (FlowSvcImpl)service;
		FlowRoot flowRoot = flowService.getFlowRoot();
		IDataCursor cursor = pipeline.getCursor();
		IData stepPipeline = IDataUtil.getIData(cursor, ServerIf.FLOW_PIPELINE);
		if ( stepPipeline == null )
			stepPipeline = IDataFactory.create();
		Object flowStep = IDataUtil.get(cursor, ServerIf.FLOW_STEP);
		
		
		
		
		FlowState fs = new FlowState(flowRoot, Namespace.current(), stepPipeline);
		fs.setFlowExceptionHandler(new FlowExceptionHandlerImpl());
		
		InvokeState is = InvokeState.getCurrentState();
		is.setFlowState(fs);
		
		FlowElement invoke = fs.invoke();
		cursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

